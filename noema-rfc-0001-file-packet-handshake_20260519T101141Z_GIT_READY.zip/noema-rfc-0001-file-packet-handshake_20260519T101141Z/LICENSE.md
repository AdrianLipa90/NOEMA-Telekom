# License Strategy Draft

This package is a draft and is not legal advice.

Recommended split:

## 1. Protocol specification

Use a permissive open license for the specification, such as Apache-2.0 or a web-standard-style specification license.

Goal: maximize adoption and establish public prior art.

## 2. Reference implementation

Use either:

- Apache-2.0 for maximal adoption, or
- dual-license / source-available license for commercial control.

## 3. Official runtime, certification, and brand

Protect through:

- trademark,
- certification terms,
- commercial support,
- official runtime licensing,
- enterprise features.

## Suggested publication model

```yaml
specification: "open"
reference_scaffold: "open or source-available"
official_runtime: "commercial/source-available optional"
trademark: "protected"
certification: "controlled"
```

## Royalty model note

Charging royalties on every use of a protocol usually harms adoption. A stronger model is to keep the protocol open while monetizing official certification, enterprise runtime, hosted services, tooling, and brand use.
