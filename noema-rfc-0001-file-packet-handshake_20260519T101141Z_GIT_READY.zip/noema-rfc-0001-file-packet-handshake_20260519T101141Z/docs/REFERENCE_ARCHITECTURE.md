# Reference Architecture

## Components

```text
noematord
noemator-rootd
noema-policy
noema-audit
noema-current
noema-snaps
noema-ports
noema-router
```

## Directory model

```text
.noema/
  CURRENT.noema.json
  snaps/
  ports/
    inbox/
    outbox/
  logi/
  logs/
  agents/
  policy/
  manifests/
```

## Data flow

```text
packet creation
→ inbox/outbox placement
→ hash verification
→ ACK generation
→ proof packet
→ snap creation
→ CURRENT update or CURRENT_UPDATE_CANDIDATE
```

## Root helper model

Root operations must be capability-scoped and auditable.

The privileged helper should not interpret semantic meaning. It should execute approved low-level actions only.

## ResEnt registry

A ResEnt may be represented as:

```yaml
resent_id: "app.terminal"
type: "process"
routes:
  episodic: true
  semantic: true
  procedural: true
policy_scope: "local"
current_state: "<pointer>"
```
