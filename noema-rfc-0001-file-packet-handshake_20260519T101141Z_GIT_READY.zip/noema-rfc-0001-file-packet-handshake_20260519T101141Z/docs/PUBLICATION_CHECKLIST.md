# Publication Checklist

Before public release:

- [ ] Remove all private keys.
- [ ] Remove all credentials.
- [ ] Verify ZIP integrity.
- [ ] Verify SHA256SUMS.
- [ ] Include LICENSE.
- [ ] Include THREAT_MODEL.
- [ ] Include SECURITY_BOUNDARIES.
- [ ] Include STATE_MACHINE.
- [ ] Include SPEC_v0.1.
- [ ] Include explicit NON_CLAIMS.
- [ ] Add version tag.
- [ ] Publish source hash.
- [ ] Decide trademark policy.
- [ ] Decide reference implementation license.
- [ ] Run secret scan.
- [ ] Run interoperability tests.
