# Security Boundaries

## Hard boundaries

NOEMA RFC-0001 MUST NOT be described as:

- guaranteed anonymous,
- guaranteed encrypted,
- quantum communication,
- physics-breaking communication,
- automatically trusted,
- safe for production without review.

## Permission boundary

Privileged actions must be isolated from semantic reasoning.

Recommended model:

```text
noematord          — unprivileged semantic daemon
noemator-rootd     — minimal privileged actuator
NOEMA policy gate  — consent and capability checks
NOEMA audit        — append-only event trace
```

The root-capable helper should be deterministic, auditable, capability-scoped, and semantically noncreative.

## Publication boundary

Public release packages must not contain:

- private keys,
- credentials,
- tokens,
- passwords,
- live secrets,
- unredacted user identifiers.

## Identity boundary

A semantic identifier is not proof of personhood, authorization, or legal identity. Authorization must be handled by policy and verification artifacts.

## CURRENT boundary

`CURRENT` is a pointer. It may be updated only through an auditable process. Historical snaps must not be modified.

## Runtime boundary

A portable CURRENT artifact may establish project-level state for an importing runtime. It does not by itself prove external live binding, network access, or global consensus.
