# NOEMA Trademark and Naming Policy Draft

This draft separates open protocol interoperability from official project identity.

## Allowed without permission

You may refer to compatibility with the public NOEMA protocol specification, for example:

```text
Compatible with NOEMA RFC-0001
Implements NOEMA File-Packet Handshake v0.1
```

## Restricted names

The following names should be treated as project marks:

```text
NOEMA
CIEL
NOEGPT
NOEMA+OR
noemator
```

Use of these names to imply official endorsement, certification, or authorship requires permission from the project owner.

## Certification language

Only approved implementations may use:

```text
Official NOEMA Node
Certified NOEMA Runtime
CIEL-Compatible Certified Runtime
```

## Non-endorsement

Compatibility does not imply endorsement.
