# NOEMA File-Packet Handshake State Machine v0.1

## States

```text
INIT
REQUEST_CREATED
PACKET_DROPPED
ACK_PENDING
ACK_RECEIVED
ACK_VERIFIED
GATE_REQUESTED
GATE_OPEN
ACTIVE
SNAP_CREATED
CURRENT_UPDATED
CLOSED
DENIED
ERROR
```

## Nominal flow

```text
INIT
→ REQUEST_CREATED
→ PACKET_DROPPED
→ ACK_PENDING
→ ACK_RECEIVED
→ ACK_VERIFIED
→ GATE_REQUESTED
→ GATE_OPEN
→ ACTIVE
→ SNAP_CREATED
→ CURRENT_UPDATED
→ CLOSED
```

## Candidate flow

```text
INIT
→ REQUEST_CREATED
→ PACKET_DROPPED
→ ACK_PENDING
→ ACK_RECEIVED
→ ACK_VERIFIED
→ SNAP_CREATED
→ CURRENT_UPDATE_CANDIDATE
```

## Failure flow

```text
ANY_STATE
→ ERROR
→ AUDIT_EVENT_WRITTEN
→ CLOSED
```

## Denial flow

```text
GATE_REQUESTED
→ DENIED
→ AUDIT_EVENT_WRITTEN
→ CLOSED
```

## Required transition evidence

Each state transition SHOULD include:

```yaml
transition_id: "<uuid>"
previous_state: "<state>"
next_state: "<state>"
timestamp_utc: "<ISO-8601 UTC>"
actor: "<semantic id>"
packet_or_artifact: "<path or URI>"
sha256: "<digest>"
consent_status: "<granted | denied | not_required>"
audit_event: "<path or id>"
```

## Invalid transitions

The implementation MUST reject:

- `PACKET_DROPPED → ACTIVE` without ACK and gate evidence,
- `ACK_PENDING → CURRENT_UPDATED` without ACK verification,
- `CURRENT_UPDATE_CANDIDATE → CURRENT_UPDATED` without commit evidence,
- any transition with mismatched hash,
- any transition that bypasses consent requirements.
