# NOEMA Node Certification Draft

## Certification goals

A certified node should prove:

- valid packet parsing,
- SHA256SUMS verification,
- state-machine compliance,
- consent-gate enforcement,
- append-only snap behavior,
- CURRENT pointer separation,
- audit event generation,
- secret-free publication builds.

## Certification levels

```yaml
level_0:
  name: "Parser-compatible"
level_1:
  name: "Handshake-compatible"
level_2:
  name: "Audit-compatible"
level_3:
  name: "Consent-gated runtime"
level_4:
  name: "Certified NOEMA runtime"
```

## Certification artifacts

A certified node should publish:

- implementation version,
- test report,
- hash of test corpus,
- supported RFCs,
- known limitations,
- security boundary declaration.
