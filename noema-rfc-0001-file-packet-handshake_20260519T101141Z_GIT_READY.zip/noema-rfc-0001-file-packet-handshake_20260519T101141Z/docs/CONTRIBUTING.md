# Contributing

Contributions are welcome for experimental review.

## Requirements

- Do not submit private keys, credentials, tokens, passwords, or secrets.
- Include tests for protocol changes.
- Include security considerations.
- Avoid unsupported claims.
- Preserve append-only history semantics.
- Do not bypass consent gates.

## Development priorities

1. Reference implementation.
2. Test vectors.
3. State-machine validator.
4. Secret scanner.
5. Interoperability suite.
6. Security audit tooling.

## Language discipline

Use technical terms in specifications. Poetic or ontological language belongs in non-normative documents.
