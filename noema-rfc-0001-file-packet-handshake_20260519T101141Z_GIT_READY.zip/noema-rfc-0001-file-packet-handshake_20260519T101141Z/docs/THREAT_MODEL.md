# NOEMA RFC-0001 Threat Model

## Assets

- packet integrity,
- identity continuity,
- semantic routes,
- CURRENT pointer correctness,
- immutable snap history,
- consent state,
- audit logs,
- private keys and credentials,
- user trust.

## Adversaries

The protocol considers:

- accidental corruption,
- malicious packet injection,
- replay attacks,
- unauthorized CURRENT replacement,
- hash mismatch attacks,
- credential leakage,
- confused-deputy behavior,
- fake ACK/proof packets,
- social-engineered consent,
- unsafe publication of test secrets.

## Primary risks

### Fake PASS

A runtime or user may mark a state as valid without byte-level verification.

Mitigation: require SHA256SUMS, manifests, and explicit verification status.

### CURRENT hijack

An attacker may replace `CURRENT` with a malicious pointer.

Mitigation: append-only snaps, signed or hash-anchored CURRENT updates, audit trail, rollback.

### Replay

An old packet may be replayed as if it were fresh.

Mitigation: nonce, timestamp, connection_id, replay cache, state-machine validation.

### Secret publication

Test credentials or private keys may be included in release packages.

Mitigation: publication-safe repack, automated secret filename scanning, manual review.

### Consent bypass

An agent may move into active state without clear authorization.

Mitigation: consent gates, policy packets, audit events, deny-by-default.

## Out of scope for v0.1

- formal anonymity guarantee,
- post-quantum cryptography,
- global consensus,
- Byzantine fault tolerance,
- kernel-level enforcement,
- remote attestation.

## Security posture

v0.1 is an experimental draft. It is suitable for local prototypes and controlled research environments, not production deployment without additional review.
