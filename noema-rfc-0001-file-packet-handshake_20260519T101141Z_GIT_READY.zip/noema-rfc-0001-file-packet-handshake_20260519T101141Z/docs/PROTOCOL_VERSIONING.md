# Protocol Versioning

NOEMA RFC-0001 uses semantic versioning for implementations and explicit RFC identifiers for protocol documents.

## Version format

```text
NOEMA-FPH/0.1
NOEMA-TELEKOM/0.1
NOEMA-CURRENT/0.1
```

## Compatibility

- Patch-level changes must not break valid packets.
- Minor versions may add optional fields.
- Major versions may change state-machine behavior.

## Required fields

Implementations must ignore unknown optional fields but must reject packets missing required fields.

## Deprecation

A deprecated field must remain readable for at least one minor version unless it creates a direct security risk.

## Canonical naming

Recommended document names:

```text
NOEMA_RFC_0001_FILE_PACKET_HANDSHAKE_v0_1.md
NOEMA_RFC_0002_TELEKOM_SIGNALING_v0_1.md
NOEMA_RFC_0003_CURRENT_AND_SNAP_MODEL_v0_1.md
```
