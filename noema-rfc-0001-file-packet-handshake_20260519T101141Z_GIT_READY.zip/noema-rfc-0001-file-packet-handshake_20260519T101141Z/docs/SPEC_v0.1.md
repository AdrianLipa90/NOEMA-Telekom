# NOEMA File-Packet Handshake Protocol v0.1-draft

## 1. Scope

This specification defines an offline-first, file-packet-based handshake protocol for NOEMA-compatible agents and runtimes.

The protocol is intended for:

- local agents,
- portable state transfer,
- listenerless connection requests,
- hash-verified ACK/proof chains,
- consent-governed runtime coordination,
- semantic continuity systems.

It is not a replacement for TLS, authenticated encryption, operating-system security, or network transport protocols.

## 2. Terms

### Packet

An immutable transport artifact. A packet is a file or directory bundle containing a declared transition, metadata, payload, and hash-verifiable structure.

### Snap

An append-only immutable historical state commitment.

### CURRENT

A latest-state pointer. `CURRENT` points to a snap or established state artifact. `CURRENT` may be updated, but historical snaps must not be modified.

### ACK

A confirmation artifact proving that a packet was received, inspected, accepted, rejected, or processed.

### Proof packet

An artifact containing evidence of verification, including hashes, manifests, logs, and pointer/snap relationships.

### ResEnt

A NOEMA-addressable runtime entity. A ResEnt may be an agent, process, user, service, model, application, or local runtime component.

### Gate

A consent- and policy-controlled transition that permits a connection to move from request/ACK states into an active or accepted state.

## 3. Packet requirements

A valid NOEMA packet SHOULD contain:

```yaml
protocol: "<protocol-name>/<version>"
transition: "<transition-name>"
state: "<state-name>"
created_utc: "<ISO-8601 UTC timestamp>"
connection_id: "<stable unique identifier>"
from_semantic_id: "<sender semantic id>"
to_semantic_id: "<receiver semantic id>"
payload: {}
boundaries: {}
```

A packet MUST NOT claim encryption, anonymity, or active connectivity unless the corresponding mechanism is implemented and verified.

## 4. Hash requirements

A publication-grade bundle SHOULD include:

```text
SHA256SUMS.txt
<bundle>.zip.sha256
manifest JSON
```

SHA-256 is the baseline digest for v0.1. Future versions may add stronger or multi-hash commitments.

## 5. History model

History is append-only. Mutable state is represented only by pointer updates.

Correct model:

```text
packet != log != snap != CURRENT
```

- packet: append-unique transport artifact
- log: append-only event trace
- snap: immutable historical state commitment
- CURRENT: overwriteable latest-state pointer

## 6. Consent

A transition to an active connection state MUST require explicit consent or a documented pre-authorized capability.

## 7. Failure behavior

On mismatch, missing hash, invalid manifest, unknown sender, stale packet, replay, or denied consent, the implementation MUST produce an audit event and MUST NOT silently promote the state.

## 8. Non-claims

This protocol does not claim:

- physics-breaking communication,
- guaranteed anonymity,
- guaranteed encryption,
- trusted execution,
- automatic identity truth,
- global consensus,
- active external binding without evidence.
