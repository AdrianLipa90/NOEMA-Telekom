# Governance Draft

## Project authority

Initial authorship and stewardship: Adrian Lipa.

## Change process

Protocol changes should be proposed as RFC documents.

Each RFC should include:

- title,
- status,
- motivation,
- specification,
- security considerations,
- compatibility impact,
- test vectors,
- reference implementation notes.

## RFC statuses

```text
DRAFT
EXPERIMENTAL
CANDIDATE
ESTABLISHED
DEPRECATED
REJECTED
```

## Security review

Changes affecting identity, consent, cryptography, CURRENT, snaps, root access, or audit behavior require explicit security review.

## Canon policy

A document is not canon merely because it exists. Canon requires declared status, hash commitment, and governance acceptance.
