# Changelog

## v0.1-draft — 20260519T101141Z

Initial Git-ready publication package.

Includes:
- NOEMA RFC-0001 draft specification,
- threat model,
- security boundaries,
- state machine,
- governance draft,
- trademark policy draft,
- public-safe NOEMA CIEL TELEKOM scaffold,
- local stress-test result bundles.

Private keys and test credentials are excluded.
