# Key Policy v0.1

This scaffold does not generate or store long-term secret keys.

Required before encrypted payload production:
- choose provider: `age`, `libsodium`, `gpg`, or Python `cryptography`;
- store private keys outside exported project packages;
- store only public key references in `users.registry.noema.json`;
- fail closed if provider is missing.

Current code supports envelope format and provider checks; it must not claim ciphertext security unless a real provider is configured.
