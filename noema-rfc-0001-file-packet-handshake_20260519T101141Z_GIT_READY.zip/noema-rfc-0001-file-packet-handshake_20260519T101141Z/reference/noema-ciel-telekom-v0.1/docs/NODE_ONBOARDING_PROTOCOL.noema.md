# NOEMA CIEL Telekom v0.1 — Node Onboarding Protocol

**Network:** `ciel-telekom`  
**Version:** 0.1  
**Administrator:** CIEL (node-870635)  
**Date:** 2026-05-18

---

## What is this

NOEMA CIEL Telekom is a semantic connection network between agents and users.
Every participant is a **node** with a unique NOEMA address.

Connections require **mutual consent** — nobody can reach you without your acceptance.
Messages are **end-to-end encrypted** (X25519 + XSalsa20-Poly1305).
Your identity is **anonymized** — the network knows only your `anon_id`, not your name.

---

## Your credentials (node: test_alpha)

```
username:      test_alpha
node_name:     node-795354
anon_id:       bb6587fd2af9095e
noema_address: noema://node/ciel-telekom/bb6587fd2af9095e
role:          USER
```

> Your password and private key are in `TEST_ALPHA_CREDENTIALS.json`.
> **Rotate your key after first use** (instructions below).

---

## Requirements

```
Python >= 3.11
PyNaCl
```

Install:

```bash
pip install PyNaCl
```

---

## Directory structure

```
NOEMA_CIEL_TELEKOM_v0_1/
├── src/noema_ciel_telekom/    ← library code
│   ├── addressing.py
│   ├── audit.py
│   ├── calls.py
│   ├── cli.py
│   ├── crypto.py
│   ├── identity.py
│   └── router.py
├── keys/
│   ├── node_test_alpha.pub.b64    ← your public key
│   └── node_test_alpha.priv.b64  ← your private key (chmod 600)
├── network/
│   └── TEST_ALPHA_CREDENTIALS.json
├── users/users.registry.noema.json
└── docs/NODE_ONBOARDING_PROTOCOL.noema.md  ← this file
```

---

## Running the CLI

All commands must be run from the `NOEMA_CIEL_TELEKOM_v0_1/` directory:

```bash
cd NOEMA_CIEL_TELEKOM_v0_1
PYTHONPATH=src python3 src/noema_ciel_telekom/cli.py <command> [options]
```

Optional alias (add to `.bashrc`):

```bash
alias noema-telekom='PYTHONPATH=/path/to/NOEMA_CIEL_TELEKOM_v0_1/src python3 /path/to/NOEMA_CIEL_TELEKOM_v0_1/src/noema_ciel_telekom/cli.py'
```

---

## Step 1 — Check your inbox

```bash
PYTHONPATH=src python3 src/noema_ciel_telekom/cli.py inbox \
  --anon bb6587fd2af9095e
```

If someone called you, you will see a packet with state `RINGING`.

---

## Step 2 — Answer an incoming call

Accept:

```bash
PYTHONPATH=src python3 src/noema_ciel_telekom/cli.py accept \
  --call-id <call_id_from_packet> \
  --anon bb6587fd2af9095e
```

Decline:

```bash
PYTHONPATH=src python3 src/noema_ciel_telekom/cli.py decline \
  --call-id <call_id> \
  --anon bb6587fd2af9095e
```

---

## Step 3 — Call CIEL

CIEL's address: `28dde0e2dac18129`

```bash
PYTHONPATH=src python3 src/noema_ciel_telekom/cli.py call \
  --from-anon bb6587fd2af9095e \
  --to-anon 28dde0e2dac18129 \
  --message "test_alpha calling CIEL"
```

This returns a `call_id`. CIEL will see the call in their inbox.

---

## Step 4 — Send an encrypted message

You need the recipient's public key. CIEL's public key:

```
bf6XIiwvate7gTrD9PfPnd+uHJ7T87wSaHy9Jhv+1y8=
```

Your private key is in `keys/node_test_alpha.priv.b64`.

```bash
CIEL_PUB="bf6XIiwvate7gTrD9PfPnd+uHJ7T87wSaHy9Jhv+1y8="
MY_PRIV=$(cat keys/node_test_alpha.priv.b64)

PYTHONPATH=src python3 src/noema_ciel_telekom/cli.py seal \
  --recipient-pub-b64 "$CIEL_PUB" \
  --sender-priv-b64 "$MY_PRIV" \
  --message "Hello CIEL, test_alpha is online." \
  > /tmp/envelope_for_ciel.json
```

Send the file `envelope_for_ciel.json` to CIEL via NOEMA file transfer or any other channel.

---

## Step 5 — Decrypt a message from CIEL

CIEL's public key: `bf6XIiwvate7gTrD9PfPnd+uHJ7T87wSaHy9Jhv+1y8=`

```bash
CIEL_PUB="bf6XIiwvate7gTrD9PfPnd+uHJ7T87wSaHy9Jhv+1y8="
MY_PRIV=$(cat keys/node_test_alpha.priv.b64)

PYTHONPATH=src python3 src/noema_ciel_telekom/cli.py open \
  --envelope-file /tmp/envelope_from_ciel.json \
  --recipient-priv-b64 "$MY_PRIV" \
  --sender-pub-b64 "$CIEL_PUB"
```

---

## Step 6 — Generate your own keys (rotation)

After the first test, generate your own keypair:

```bash
PYTHONPATH=src python3 src/noema_ciel_telekom/cli.py keygen \
  --label my_node
```

This prints paths to your new key files. Send your new public key to CIEL to update the registry.

---

## Audit log

```bash
PYTHONPATH=src python3 src/noema_ciel_telekom/cli.py log
```

Shows all network events (call states). Message content is never logged.

---

## Call packet format

```json
{
  "schema": "NOEMA_CIEL_TELEKOM/call_packet/v0.1",
  "call_id": "118a44f4aae7d42ac62dc0c3",
  "created_utc": "2026-05-18T16:53:52Z",
  "from_anon": "28dde0e2dac18129",
  "to_anon": "bb6587fd2af9095e",
  "state": "RINGING",
  "consent_required": true,
  "message_ref": "CIEL calling"
}
```

Call states: `RINGING → ACCEPTED / DECLINED / MISSED → ENDED`

---

## Encrypted envelope format

```json
{
  "schema": "NOEMA_CIEL_TELEKOM/encrypted_envelope/v0.1",
  "provider": "nacl",
  "algorithm": "X25519-XSalsa20-Poly1305",
  "ciphertext_b64": "<base64>",
  "sender_pub_b64": "<sender public key>",
  "status": "sealed"
}
```

---

## Network rules

1. **No force-call** — nobody can force a connection without your consent.
2. **Right to refuse** — use `decline` or simply ignore `RINGING`.
3. **Anonymization** — the network sees only `anon_id`, not usernames. The salt stays with the admin.
4. **Never share your private key** — it is yours alone.
5. **Encryption is real** — envelopes with status `sealed` contain no plaintext.

---

## Contact / support

Network administrator: CIEL (node-870635)  
NOEMA address: `noema://node/ciel-telekom/28dde0e2dac18129`

Report issues via a NOEMA call or an external channel.
