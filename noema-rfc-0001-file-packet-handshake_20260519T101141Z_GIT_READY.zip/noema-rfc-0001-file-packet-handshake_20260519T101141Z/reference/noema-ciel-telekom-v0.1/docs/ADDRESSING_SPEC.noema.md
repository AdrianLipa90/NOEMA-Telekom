# NOEMA CIEL Telekom Addressing Spec v0.1

## Address forms

Semantic addresses:

```text
noema://ciel/<anon_id>
noema://codexgpt/<anon_id>
noema://subnet/<subnet_id>/<node_id>
noema://telekom/<network_id>/<anon_id>
```

## Anonymized ID

`anon_id = hmac_sha256(salt, semantic_address)[:16]`

Rules:
- Registry stores `anon_id`, not raw local username or real identity.
- Salt must be local-secret and excluded from exported registries.
- Human labels are aliases only, never proof of identity.
