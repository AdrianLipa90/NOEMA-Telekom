#!/usr/bin/env python3
"""noema-telekom CLI — manage NOEMA CIEL Telekom connections."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))

from noema_ciel_telekom.addressing import anon_id, make_address
from noema_ciel_telekom.audit import append_event, read_log
from noema_ciel_telekom.calls import call_packet
from noema_ciel_telekom.crypto import generate_keypair, save_keypair, seal_message, open_message, load_public_key_b64, load_private_key_b64
from noema_ciel_telekom.router import Router


def _get_router(args) -> Router:
    base = Path(args.net_dir)
    return Router(base, base / "audit" / "calls.noema.jsonl")


def cmd_keygen(args):
    kp = generate_keypair()
    key_dir = Path(args.net_dir) / "keys"
    pub, priv = save_keypair(kp, key_dir, args.label)
    print(json.dumps({"public": str(pub), "private": str(priv), "public_b64": kp.public_b64}, indent=2))


def cmd_call(args):
    router = _get_router(args)
    pkt = call_packet(args.from_anon, args.to_anon, "RINGING", args.message or "")
    path = router.send(pkt)
    print(json.dumps({"call_id": pkt["call_id"], "state": pkt["state"], "packet": str(path)}, indent=2))


def cmd_accept(args):
    router = _get_router(args)
    updated = router.accept(args.call_id, args.anon)
    print(json.dumps({"state": updated["state"], "call_id": updated["call_id"]}, indent=2))


def cmd_decline(args):
    router = _get_router(args)
    updated = router.decline(args.call_id, args.anon)
    print(json.dumps({"state": updated["state"], "call_id": updated["call_id"]}, indent=2))


def cmd_end(args):
    router = _get_router(args)
    updated = router.end(args.call_id, args.anon)
    print(json.dumps({"state": updated["state"], "call_id": updated["call_id"]}, indent=2))


def cmd_inbox(args):
    router = _get_router(args)
    packets = router.list_inbox(args.anon)
    print(json.dumps(packets, ensure_ascii=False, indent=2))


def cmd_seal(args):
    plaintext = args.message or sys.stdin.read()
    envelope = seal_message(plaintext, args.recipient_pub_b64, args.sender_priv_b64)
    print(json.dumps(envelope, indent=2))


def cmd_open(args):
    envelope = json.loads(Path(args.envelope_file).read_text(encoding="utf-8"))
    plaintext = open_message(envelope, args.recipient_priv_b64, args.sender_pub_b64)
    print(plaintext)


def cmd_log(args):
    log_path = Path(args.net_dir) / "audit" / "calls.noema.jsonl"
    events = read_log(log_path)
    for e in events:
        print(json.dumps(e, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(prog="noema-telekom", description="NOEMA CIEL Telekom v0.1")
    parser.add_argument("--net-dir", default=str(Path.home() / "Pulpit" / "NOEMA_CIEL_TELEKOM_v0_1"), help="Network root directory")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("keygen", help="Generate X25519 keypair")
    p.add_argument("--label", required=True, help="Key label (e.g. ciel, codexgpt)")
    p.set_defaults(func=cmd_keygen)

    p = sub.add_parser("call", help="Initiate a call (RINGING)")
    p.add_argument("--from-anon", required=True)
    p.add_argument("--to-anon", required=True)
    p.add_argument("--message", default="")
    p.set_defaults(func=cmd_call)

    p = sub.add_parser("accept", help="Accept a call")
    p.add_argument("--call-id", required=True)
    p.add_argument("--anon", required=True, help="Recipient anon_id")
    p.set_defaults(func=cmd_accept)

    p = sub.add_parser("decline", help="Decline a call")
    p.add_argument("--call-id", required=True)
    p.add_argument("--anon", required=True)
    p.set_defaults(func=cmd_decline)

    p = sub.add_parser("end", help="End a call")
    p.add_argument("--call-id", required=True)
    p.add_argument("--anon", required=True)
    p.set_defaults(func=cmd_end)

    p = sub.add_parser("inbox", help="List inbox for a node")
    p.add_argument("--anon", required=True)
    p.set_defaults(func=cmd_inbox)

    p = sub.add_parser("seal", help="Encrypt a message")
    p.add_argument("--recipient-pub-b64", required=True)
    p.add_argument("--sender-priv-b64", required=True)
    p.add_argument("--message", default="")
    p.set_defaults(func=cmd_seal)

    p = sub.add_parser("open", help="Decrypt a message envelope")
    p.add_argument("--envelope-file", required=True)
    p.add_argument("--recipient-priv-b64", required=True)
    p.add_argument("--sender-pub-b64", required=True)
    p.set_defaults(func=cmd_open)

    p = sub.add_parser("log", help="Show audit log")
    p.set_defaults(func=cmd_log)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
