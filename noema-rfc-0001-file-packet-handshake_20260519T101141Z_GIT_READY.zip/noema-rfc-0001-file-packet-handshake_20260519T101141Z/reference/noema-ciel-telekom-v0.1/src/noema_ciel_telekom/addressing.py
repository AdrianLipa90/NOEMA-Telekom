from __future__ import annotations

import hmac
import hashlib


def anon_id(secret_salt: str, semantic_address: str, length: int = 16) -> str:
    if not secret_salt:
        raise ValueError("secret_salt required")
    if not semantic_address.startswith("noema://"):
        raise ValueError("semantic_address must start with noema://")
    digest = hmac.new(secret_salt.encode("utf-8"), semantic_address.encode("utf-8"), hashlib.sha256).hexdigest()
    return digest[:length]


def make_address(kind: str, anon: str, network: str = "ciel-telekom") -> str:
    if not anon or "/" in anon:
        raise ValueError("invalid anon segment")
    return f"noema://{kind}/{network}/{anon}"
