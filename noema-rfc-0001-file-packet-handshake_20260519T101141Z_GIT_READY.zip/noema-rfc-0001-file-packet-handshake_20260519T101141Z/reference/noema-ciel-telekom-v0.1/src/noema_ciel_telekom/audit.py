from __future__ import annotations

import datetime
import json
from pathlib import Path


def _utc_now() -> str:
    return datetime.datetime.now(datetime.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def append_event(log_path: Path, event_type: str, payload: dict) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "ts": _utc_now(),
        "event": event_type,
        **{k: v for k, v in payload.items() if k != "ts"},
    }
    with log_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")


def read_log(log_path: Path) -> list[dict]:
    if not log_path.exists():
        return []
    return [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines() if line.strip()]
