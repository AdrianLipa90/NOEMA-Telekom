from __future__ import annotations

import base64
import importlib.util
import json
import os
from pathlib import Path
from typing import NamedTuple


class CryptoUnavailable(RuntimeError):
    pass


def available_providers() -> dict[str, bool]:
    return {
        "cryptography": importlib.util.find_spec("cryptography") is not None,
        "nacl": importlib.util.find_spec("nacl") is not None,
    }


def _require_nacl() -> None:
    if not available_providers()["nacl"]:
        raise CryptoUnavailable("PyNaCl not installed. Run: pip install PyNaCl")


class KeyPair(NamedTuple):
    public_b64: str
    private_b64: str


def generate_keypair() -> KeyPair:
    _require_nacl()
    from nacl.public import PrivateKey
    sk = PrivateKey.generate()
    return KeyPair(
        public_b64=base64.b64encode(bytes(sk.public_key)).decode(),
        private_b64=base64.b64encode(bytes(sk)).decode(),
    )


def save_keypair(keypair: KeyPair, key_dir: Path, label: str) -> tuple[Path, Path]:
    key_dir.mkdir(parents=True, exist_ok=True)
    pub_path = key_dir / f"{label}.pub.b64"
    priv_path = key_dir / f"{label}.priv.b64"
    pub_path.write_text(keypair.public_b64 + "\n", encoding="utf-8")
    priv_path.write_text(keypair.private_b64 + "\n", encoding="utf-8")
    priv_path.chmod(0o600)
    return pub_path, priv_path


def load_public_key_b64(path: Path) -> str:
    return path.read_text(encoding="utf-8").strip()


def load_private_key_b64(path: Path) -> str:
    return path.read_text(encoding="utf-8").strip()


def seal_message(plaintext: str, recipient_public_b64: str, sender_private_b64: str) -> dict:
    """Encrypt plaintext with NaCl Box (X25519 + XSalsa20-Poly1305). Returns envelope dict."""
    _require_nacl()
    from nacl.public import Box, PrivateKey, PublicKey
    sender_sk = PrivateKey(base64.b64decode(sender_private_b64))
    recipient_pk = PublicKey(base64.b64decode(recipient_public_b64))
    box = Box(sender_sk, recipient_pk)
    nonce = os.urandom(Box.NONCE_SIZE)
    ciphertext = box.encrypt(plaintext.encode("utf-8"), nonce)
    # ciphertext already contains nonce prefix from PyNaCl EncryptedMessage
    return {
        "schema": "NOEMA_CIEL_TELEKOM/encrypted_envelope/v0.1",
        "provider": "nacl",
        "algorithm": "X25519-XSalsa20-Poly1305",
        "ciphertext_b64": base64.b64encode(bytes(ciphertext)).decode(),
        "sender_pub_b64": base64.b64encode(bytes(sender_sk.public_key)).decode(),
        "status": "sealed",
    }


def open_message(envelope: dict, recipient_private_b64: str, sender_public_b64: str) -> str:
    """Decrypt envelope. Raises on failure."""
    _require_nacl()
    from nacl.public import Box, PrivateKey, PublicKey
    if envelope.get("status") != "sealed":
        raise ValueError("envelope is not sealed")
    recipient_sk = PrivateKey(base64.b64decode(recipient_private_b64))
    sender_pk = PublicKey(base64.b64decode(sender_public_b64))
    box = Box(recipient_sk, sender_pk)
    raw = base64.b64decode(envelope["ciphertext_b64"])
    return box.decrypt(raw).decode("utf-8")


def envelope_stub(sender: str, recipient: str, public_key_ref: str) -> dict:
    """Metadata skeleton only — no fake ciphertext. Use seal_message for real encryption."""
    return {
        "schema": "NOEMA_CIEL_TELEKOM/encrypted_envelope/v0.1",
        "provider": "UNCONFIGURED",
        "algorithm": "UNCONFIGURED",
        "sender": sender,
        "recipient": recipient,
        "ciphertext_b64": "",
        "public_key_ref": public_key_ref,
        "status": "crypto_provider_required_before_use",
    }
