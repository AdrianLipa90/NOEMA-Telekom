from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
from pathlib import Path


ANCHOR_VERSION = "1"


def _derive_anon_id(username: str, password: str, network_salt: str, length: int = 16) -> str:
    """Derive deterministic anon_id from credentials. Password never stored."""
    key = hmac.new(
        network_salt.encode("utf-8"),
        f"{ANCHOR_VERSION}:{username}:{password}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return key[:length]


def _derive_node_number(anon_id: str) -> str:
    h = hashlib.sha256(anon_id.encode()).digest()
    n = int.from_bytes(h[:3], "big") % 1_000_000
    return f"{n:06d}"


def register_node(
    username: str,
    password: str,
    public_key_b64: str,
    registry_path: Path,
    network_salt: str,
    role: str = "USER",
) -> dict:
    registry_path.parent.mkdir(parents=True, exist_ok=True)

    if registry_path.exists():
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
    else:
        registry = {"schema": "NOEMA_CIEL_TELEKOM/user_registry/v0.1", "users": []}

    for u in registry["users"]:
        if u["username_hash"] == _username_hash(username, network_salt):
            raise ValueError(f"username already registered")

    anon_id = _derive_anon_id(username, password, network_salt)
    node_number = _derive_node_number(anon_id)
    node_name = f"node-{node_number}"

    entry = {
        "anon_id": anon_id,
        "username_hash": _username_hash(username, network_salt),
        "node_name": node_name,
        "public_label": username,
        "role": role,
        "public_key_b64": public_key_b64,
        "consent_state": "ACTIVE",
    }
    registry["users"].append(entry)
    registry_path.write_text(json.dumps(registry, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return entry


def authenticate_node(username: str, password: str, registry_path: Path, network_salt: str) -> dict:
    if not registry_path.exists():
        raise ValueError("registry not found")
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    anon_id = _derive_anon_id(username, password, network_salt)
    uhash = _username_hash(username, network_salt)
    for u in registry["users"]:
        if u["username_hash"] == uhash and u["anon_id"] == anon_id:
            return u
    raise ValueError("invalid username or password")


def _username_hash(username: str, network_salt: str) -> str:
    return hmac.new(
        network_salt.encode("utf-8"),
        f"uname:{username}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()[:32]


def generate_network_salt() -> str:
    return secrets.token_hex(32)


def make_identity_card(entry: dict) -> dict:
    return {
        "schema": "NOEMA_CIEL_TELEKOM/identity_card/v0.1",
        "anon_id": entry["anon_id"],
        "node_name": entry["node_name"],
        "role": entry["role"],
        "public_key_b64": entry["public_key_b64"],
        "consent_state": entry["consent_state"],
        "network": "ciel-telekom",
        "noema_address": f"noema://node/ciel-telekom/{entry['anon_id']}",
    }
