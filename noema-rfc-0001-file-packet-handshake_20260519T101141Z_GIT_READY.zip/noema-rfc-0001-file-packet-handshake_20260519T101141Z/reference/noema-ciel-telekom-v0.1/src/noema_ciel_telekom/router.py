from __future__ import annotations

import json
from pathlib import Path

from .audit import append_event
from .calls import write_packet, VALID_STATES


class Router:
    """File-based packet router. Delivers call packets to node inboxes."""

    def __init__(self, base_dir: Path, audit_log: Path):
        self.base_dir = base_dir
        self.audit_log = audit_log

    def _inbox(self, anon_id: str) -> Path:
        return self.base_dir / "nodes" / anon_id / "inbox"

    def _display(self, anon_id: str) -> Path:
        return self.base_dir / "nodes" / anon_id / "display"

    def send(self, packet: dict) -> Path:
        to_anon = packet["to_anon"]
        inbox = self._inbox(to_anon)
        path = write_packet(packet, inbox)
        self._update_display(to_anon, packet)
        append_event(self.audit_log, "CALL_SENT", {
            "call_id": packet["call_id"],
            "from": packet["from_anon"],
            "to": packet["to_anon"],
            "state": packet["state"],
        })
        return path

    def _update_display(self, anon_id: str, packet: dict) -> None:
        display_dir = self._display(anon_id)
        display_dir.mkdir(parents=True, exist_ok=True)
        display_file = display_dir / "CURRENT_CALL.noema_display.json"
        display = {
            "schema": "NOEMA_CIEL_TELEKOM/display/v0.1",
            "node": anon_id,
            "call_id": packet["call_id"],
            "from_anon": packet["from_anon"],
            "state": packet["state"],
            "consent_required": packet["consent_required"],
            "message_ref": packet.get("message_ref", ""),
            "updated_utc": packet["created_utc"],
        }
        display_file.write_text(json.dumps(display, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def accept(self, call_id: str, to_anon: str) -> dict:
        return self._transition(call_id, to_anon, "ACCEPTED")

    def decline(self, call_id: str, to_anon: str) -> dict:
        return self._transition(call_id, to_anon, "DECLINED")

    def end(self, call_id: str, to_anon: str) -> dict:
        return self._transition(call_id, to_anon, "ENDED")

    def _transition(self, call_id: str, to_anon: str, new_state: str) -> dict:
        if new_state not in VALID_STATES:
            raise ValueError(f"invalid state: {new_state}")
        inbox = self._inbox(to_anon)
        packets = sorted(inbox.glob(f"*_{call_id}.*.json")) if inbox.exists() else []
        if not packets:
            raise FileNotFoundError(f"call {call_id} not found in inbox of {to_anon}")
        original = json.loads(packets[-1].read_text(encoding="utf-8"))
        original["state"] = new_state
        updated_path = write_packet(original, inbox)
        self._update_display(to_anon, original)
        append_event(self.audit_log, "CALL_STATE_CHANGED", {
            "call_id": call_id,
            "to": to_anon,
            "state": new_state,
        })
        return original

    def list_inbox(self, anon_id: str) -> list[dict]:
        inbox = self._inbox(anon_id)
        if not inbox.exists():
            return []
        packets = []
        for p in sorted(inbox.glob("*.json")):
            try:
                packets.append(json.loads(p.read_text(encoding="utf-8")))
            except Exception:
                pass
        return packets
