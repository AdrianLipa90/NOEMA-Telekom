from __future__ import annotations

import json
from pathlib import Path


def load_registry(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def add_user(registry: dict, anon_id: str, public_label: str, role: str, public_key_ref: str, consent_state: str = "PENDING") -> dict:
    if role not in {"ADMIN", "USER", "SERVICE", "OBSERVER"}:
        raise ValueError("invalid role")
    if consent_state not in {"ACTIVE", "PAUSED", "REVOKED", "PENDING"}:
        raise ValueError("invalid consent_state")
    user = {
        "anon_id": anon_id,
        "public_label": public_label,
        "role": role,
        "consent_state": consent_state,
        "public_key_ref": public_key_ref,
    }
    registry.setdefault("users", []).append(user)
    return user
