"""NOEMA CIEL Telekom v0.1 reference package."""
__version__ = "0.1.0"
