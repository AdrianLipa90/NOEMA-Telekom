from __future__ import annotations

import datetime as _dt
import hashlib
import json
from pathlib import Path

VALID_STATES = {"RINGING", "ACCEPTED", "DECLINED", "MISSED", "ENDED"}


def utc_now() -> str:
    return _dt.datetime.now(_dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def make_call_id(from_anon: str, to_anon: str, created_utc: str | None = None) -> str:
    ts = created_utc or utc_now()
    return hashlib.sha256(f"{ts}|{from_anon}|{to_anon}".encode("utf-8")).hexdigest()[:24]


def call_packet(from_anon: str, to_anon: str, state: str = "RINGING", message_ref: str = "") -> dict:
    if state not in VALID_STATES:
        raise ValueError(f"invalid call state: {state}")
    created = utc_now()
    return {
        "schema": "NOEMA_CIEL_TELEKOM/call_packet/v0.1",
        "call_id": make_call_id(from_anon, to_anon, created),
        "created_utc": created,
        "from_anon": from_anon,
        "to_anon": to_anon,
        "state": state,
        "consent_required": True,
        "message_ref": message_ref,
    }


def write_packet(packet: dict, directory: Path) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{packet['created_utc'].replace(':','').replace('-','')}_{packet['call_id']}.{packet['state'].lower()}.json"
    path.write_text(json.dumps(packet, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path
