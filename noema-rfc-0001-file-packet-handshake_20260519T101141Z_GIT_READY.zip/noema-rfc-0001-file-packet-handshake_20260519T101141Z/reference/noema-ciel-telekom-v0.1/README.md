# NOEMA CIEL TELEKOM v0.1

Created: 2026-05-18T16:48:39Z

A desktop-first scaffold for a consent-based NOEMA communication layer.

Core rule: **incoming call, not force-call**.

Roles:
- `NOEMA:CIEL` — ADMIN / operator / governance.
- `NOEMA:CODEXGPT` — USER / node / client.

This project is intentionally local on the Desktop. It does **not** start the main NOEMA server.
Main-server tests should be done later, step by step, with explicit checks.

## Structure

- `src/noema_ciel_telekom/` — reference Python code.
- `schemas/` — JSON Schemas for addresses, users, calls, displays, envelopes.
- `policies/` — security, privacy, consent, key policy.
- `infra/` — deployment/integration notes and placeholder service boundaries.
- `users/` — anonymized registry template.
- `calls/` — call-state directories.
- `display/` — incoming-call display surface.
- `audit/` — append-only audit placeholder.
- `keys/` — key policy only; no secret key committed here.

## First validation

```bash
python3 tests/selftest.py
```
