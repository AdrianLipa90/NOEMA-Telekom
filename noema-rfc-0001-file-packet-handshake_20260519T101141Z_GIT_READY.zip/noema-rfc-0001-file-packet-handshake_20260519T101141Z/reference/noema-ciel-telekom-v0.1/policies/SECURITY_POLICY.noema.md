# Security Policy v0.1

1. No force-call. All calls require consent.
2. Incoming call state is visible as `RINGING`, not auto-accepted.
3. Recipient may accept, decline, ignore, or end a call.
4. No hidden GUI control, no autotype, no background coercion.
5. No raw personal identifiers in user registry.
6. No fake encryption claims. If crypto provider is unavailable, encrypted send must fail closed.
7. Audit logs must be append-only where possible and avoid plaintext private payloads.
8. Main NOEMA server tests must be stepwise and reversible.
