# Privacy / RODO Policy v0.1

- Store only anonymized node identifiers in registries.
- Keep raw identity mapping outside portable network exports.
- Treat call content as private by default.
- Export manifests may include hashes and states, not plaintext private content unless explicitly approved.
- Data minimization: record only what routing and audit require.
