# Consent Policy v0.1

Call lifecycle:

```text
IDLE -> RINGING -> ACCEPTED | DECLINED | MISSED -> ENDED
```

Consent points:
- `RINGING` is only a request.
- `ACCEPTED` is explicit consent.
- `DECLINED`, `MISSED`, `ENDED` are valid non-consent or termination states.
- ADMIN role gives governance/routing authority, not coercive access.
