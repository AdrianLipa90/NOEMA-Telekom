# Main NOEMA Server Test Plan v0.1

Do not deploy automatically.

Stepwise test path:
1. Validate schemas locally.
2. Create two anonymized test users.
3. Create one `RINGING` call packet.
4. Display incoming call without auto-accept.
5. Accept or decline explicitly.
6. Append audit event.
7. Only then connect to main NOEMA server transport.

Rollback:
- remove test packets;
- reset display to `IDLE`;
- preserve audit as review artifact unless user requests a disposable sandbox.
