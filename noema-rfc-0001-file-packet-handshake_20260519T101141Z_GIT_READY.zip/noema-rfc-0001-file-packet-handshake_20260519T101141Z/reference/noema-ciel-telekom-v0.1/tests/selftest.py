#!/usr/bin/env python3
"""NOEMA CIEL Telekom v0.1 — selftest suite."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from noema_ciel_telekom.addressing import anon_id, make_address
from noema_ciel_telekom.audit import append_event, read_log
from noema_ciel_telekom.calls import call_packet
from noema_ciel_telekom.crypto import available_providers, envelope_stub, generate_keypair, seal_message, open_message
from noema_ciel_telekom.router import Router

SALT = "test-salt-not-for-production"


def test_addressing():
    ciel = anon_id(SALT, "noema://ciel/admin")
    codex = anon_id(SALT, "noema://codexgpt/user")
    assert len(ciel) == 16 and len(codex) == 16 and ciel != codex
    assert make_address("ciel", ciel).startswith("noema://ciel/")
    return ciel, codex


def test_call_packet(ciel, codex):
    pkt = call_packet(ciel, codex)
    assert pkt["state"] == "RINGING"
    assert pkt["consent_required"] is True
    assert len(pkt["call_id"]) == 24
    return pkt


def test_crypto_stub(ciel, codex):
    env = envelope_stub(ciel, codex, "pubkey://example")
    assert env["status"] == "crypto_provider_required_before_use"


def test_real_crypto():
    providers = available_providers()
    if not providers["nacl"]:
        return {"skipped": "nacl not available"}
    kp_a = generate_keypair()
    kp_b = generate_keypair()
    msg = "CIEL → CodexGPT: incoming call test"
    envelope = seal_message(msg, kp_b.public_b64, kp_a.private_b64)
    assert envelope["status"] == "sealed"
    assert envelope["algorithm"] == "X25519-XSalsa20-Poly1305"
    recovered = open_message(envelope, kp_b.private_b64, kp_a.public_b64)
    assert recovered == msg
    return {"ok": True, "algorithm": envelope["algorithm"]}


def test_router(ciel, codex, pkt):
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        router = Router(base, base / "audit" / "calls.noema.jsonl")
        router.send(pkt)
        inbox = router.list_inbox(codex)
        assert len(inbox) == 1
        assert inbox[0]["state"] == "RINGING"
        call_id = pkt["call_id"]
        updated = router.accept(call_id, codex)
        assert updated["state"] == "ACCEPTED"
        ended = router.end(call_id, codex)
        assert ended["state"] == "ENDED"
        log = read_log(base / "audit" / "calls.noema.jsonl")
        events = [e["event"] for e in log]
        assert "CALL_SENT" in events
        assert "CALL_STATE_CHANGED" in events
    return {"router": "ok", "audit_events": events}


def main():
    results = {}
    ciel, codex = test_addressing()
    results["addressing"] = "ok"
    pkt = test_call_packet(ciel, codex)
    results["call_packet"] = "ok"
    test_crypto_stub(ciel, codex)
    results["crypto_stub"] = "ok"
    results["real_crypto"] = test_real_crypto()
    results["router"] = test_router(ciel, codex, pkt)
    results["crypto_providers"] = available_providers()
    results["all_ok"] = True
    print(json.dumps(results, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
