# Security Policy

This repository is an experimental draft protocol package.

Do not publish:
- private keys,
- credentials,
- tokens,
- passwords,
- live endpoint secrets,
- unredacted personal identifiers.

If you find a secret or vulnerability, report it privately to the project maintainer before public disclosure.

The v0.1 protocol is not production-certified.
