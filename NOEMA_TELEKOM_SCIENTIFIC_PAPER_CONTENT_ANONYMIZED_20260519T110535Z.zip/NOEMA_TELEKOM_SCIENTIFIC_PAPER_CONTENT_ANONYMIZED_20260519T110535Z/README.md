# NOEMA Telekom paper - content-anonymized version

Author metadata is preserved: Adrian Lipa.

This version anonymizes protocol/example content that directly referenced CIEL/USERGPT/USER007 addressing.

## Replacement log

```json
[
  {
    "from": "noema://ciel/<anon_id>",
    "to": "noema://agent/<anon_id>",
    "count": 1
  },
  {
    "from": "noema://codexgpt/<anon_id>",
    "to": "noema://peer/<anon_id>",
    "count": 1
  },
  {
    "from": "reference/noema-ciel-telekom-v0.1/",
    "to": "reference/noema-telekom-scaffold-v0.1/",
    "count": 1
  },
  {
    "from": "\"protocol\": \"NOEMA_USERGPT_PROXY_CONNECT_REQUEST/0.1\"",
    "to": "\"protocol\": \"NOEMA_PROXY_CONNECT_REQUEST/0.1\"",
    "count": 1
  },
  {
    "from": "\"transition\": \"USERGPT_PROXY_CONNECT_REQUEST\"",
    "to": "\"transition\": \"PROXY_CONNECT_REQUEST\"",
    "count": 1
  },
  {
    "from": "\"connection_id\": \"noema:usergpt:connection-request:<nonce>\"",
    "to": "\"connection_id\": \"noema:entity:connection-request:<nonce>\"",
    "count": 1
  },
  {
    "from": "\"from_semantic_id\": \"NOEMA:USERGPT:CIEL_SESSION\"",
    "to": "\"from_semantic_id\": \"NOEMA:ENTITY_A:SESSION\"",
    "count": 1
  },
  {
    "from": "\"to_semantic_id\": \"NOEMA:USER007:PROXY\"",
    "to": "\"to_semantic_id\": \"NOEMA:ENTITY_B:PROXY\"",
    "count": 1
  }
]
```

## Verification

- compiled_pdf: True
- remaining_sensitive_protocol_identifiers: {}
